#include <vector>


int solution(std::vector<int> A)
{
    int max = 0;
    int num_rows = 0;
    for (int i = 0; i < A.size() - 1; ++i)
    {
        if (A[i] > max)
        {
            max = A[i];
            //max = A[i];
            num_rows++;
        }
        return num_rows;

    }
}


int main(void)
{
    std::vector<int> A = { 5,4,3,6,1 };

    int sol = solution(A);



}